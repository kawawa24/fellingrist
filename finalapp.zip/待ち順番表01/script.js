const firebaseURL = "https://fir-felling-rist-default-rtdb.firebaseio.com/";

async function setCustomUUID() {
    const uuid = document.getElementById("uuidInput").value.trim();
    if (!uuid) {
        alert("UUIDを入力してください。");
        return;
    }

    try {
        const response = await fetch(`${firebaseURL}reservations.json?orderBy="uuid"&equalTo="${uuid}"`);
        const data = await response.json();

        if (Object.keys(data).length === 0) {
            alert("データが見つかりませんでした。");
        } else {
            alert("データが見つかりました！");
            localStorage.setItem("selectedUUID", uuid);
            window.location.href = "queue.html";
        }
    } catch (error) {
        console.error("エラー:", error);
        alert("データの取得に失敗しました。");
    }
}

async function loadQueue() {
    const selectedUUID = localStorage.getItem("selectedUUID");
    let url = `${firebaseURL}reservations.json`;

    if (selectedUUID) {
        url = `${firebaseURL}reservations/${selectedUUID}.json`;
    }

    const response = await fetch(url);
    const data = await response.json();

    document.getElementById("priorityList").innerHTML = formatQueue(data, "優先");
    document.getElementById("normalList").innerHTML = formatQueue(data, "通常枠💗");
}

function formatQueue(data, queueType) {
    return Object.values(data)
        .filter(item => item.queue === queueType)
        .map(item => `<li>${item.name} - ${item.content}</li>`)
        .join("");
}

window.onload = function () {
    if (!localStorage.getItem("visitedBefore")) {
        window.location.href = "save.html";
        localStorage.setItem("visitedBefore", "true");
    }
};
