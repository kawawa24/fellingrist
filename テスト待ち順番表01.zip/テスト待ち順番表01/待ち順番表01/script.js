// Firebaseなどで待ち順を管理する場合の例
const firebaseURL = "https://creating-fortune-felling-81d49-default-rtdb.firebaseio.com/";

async function fetchData() {
    const priorityData = await getFirebaseData("priority");
    const normalData = await getFirebaseData("normal");

    displayQueue("priorityQueue", priorityData);
    displayQueue("normalQueue", normalData);

    document.getElementById("priorityCount").innerText = priorityData.length;
    document.getElementById("normalCount").innerText = normalData.length;
}

async function getFirebaseData(queueType) {
    const response = await fetch(firebaseURL + queueType + ".json");
    const data = await response.json();
    return data ? Object.entries(data).map(([id, item]) => ({ id, ...item })) : [];
}

function displayQueue(elementId, data) {
    let queueElement = document.getElementById(elementId);
    queueElement.innerHTML = "";

    data.slice(0, 3).forEach((item, index) => {
        let div = document.createElement("div");
        div.textContent = `${index + 1}. ${item.name} (${item.content})`;
        queueElement.appendChild(div);
    });

    if (data.length > 3) {
        let extra = document.createElement("div");
        extra.textContent = `その他${data.length - 3}名`;
        queueElement.appendChild(extra);
    }
}

document.addEventListener("keydown", async function(event) {
    if (!isNaN(event.key)) {
        selectedIndex += event.key;
    } else if (event.key === "Enter") {
        await moveToPriority();
    } else if (event.key === "z") {
        await deleteFromQueue("priority"); 
    } else if (event.key === "x") {
        await deleteFromQueue("normal");
    }
});

window.onload = fetchData;
